#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cstk2.h"

// Function to convert an integer pointer to a string
char *intToString(void *data) {
    int *num = (int *)data;
    char *str = (char *)malloc(12); // Enough space for an int
    sprintf(str, "%d", *num);
    return str;
}

// Function to convert an account structure to a string
typedef struct {
    char name[50];
    int balance;
} Account;

char *accountToString(void *data) {
    Account *acc = (Account *)data;
    char *str = (char *)malloc(strlen(acc->name) + 20); // Enough for "name: balance"
    sprintf(str, "%s: %d", acc->name, acc->balance);
    return str;
}

int main() {
    printf("Testing Stack with Integers\n");

    // Create a stack with capacity 5
    Stack *intStack = stk_create(5);
    int a = 10, b = 20, c = 30;

    // Push values
    stk_push(intStack, &a);
    stk_push(intStack, &b);
    stk_push(intStack, &c);

    // Print stack contents
    char *intStackStr = stk_toString(intStack, intToString);
    printf("Stack contents: %s\n", intStackStr);
    free(intStackStr);

    // Pop one element and check
    int *popped = (int *)stk_pop(intStack);
    printf("Popped value: %d\n", *popped);

    // Destroy stack
    stk_destroy(intStack);

    printf("\nTesting Stack with Accounts\n");

    // Create stack for accounts
    Stack *accStack = stk_create(3);
    Account acc1 = {"Alice", 100};
    Account acc2 = {"Bob", 200};

    // Push 
}