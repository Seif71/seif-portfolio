package main

import "fmt"

func main() {
    // If-else
    x := 10
    if x > 5 {
        fmt.Println("x is greater than 5")
    } else {
        fmt.Println("x is 5 or less")
    }

    // Switch (no break needed)
    switch x {
    case 10:
        fmt.Println("x is 10")
    default:
        fmt.Println("x is not 10")
    }

    // For loop (Go has no while/do-while)
    for i := 0; i < 3; i++ {
        fmt.Println("Loop:", i)
    }

    // Range loop
    arr := []string{"a", "b", "c"}
    for i, v := range arr {
        fmt.Printf("Index %d: %s\n", i, v)
    }

    // Go doesn't have "goto" in common use, but it exists
    labelTest()
}

func labelTest() {
    fmt.Println("Before Goto")
    goto skip
    fmt.Println("This won't be printed")

skip:
    fmt.Println("After Goto")
}
