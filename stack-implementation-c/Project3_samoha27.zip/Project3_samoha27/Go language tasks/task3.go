package main

import "fmt"

func main() {
    // Basic types
    var a int = 10
    var b float64 = 5.5
    var c bool = true
    var d string = "Hello, Go!"

    // Aggregate types
    arr := [3]int{1, 2, 3}   // Array
    slice := []int{4, 5, 6}  // Slice
    m := map[string]int{"one": 1, "two": 2} // Map
    type Person struct { name string; age int } // Struct
    p := Person{"Alice", 25}

    // Operators
    sum := a + int(b) // Type conversion needed
    fmt.Println(a, b, c, d, arr, slice, m, p)
    fmt.Println("Sum:", sum)
}
