package main

import "fmt"

// Function type
type operation func(int, int) int

// Function that takes another function as an argument
func applyOperation(a, b int, op operation) int {
    return op(a, b)
}

func add(x, y int) int {
    return x + y
}

func main() {
    // Assigning a function to a variable
    var op operation = add
    fmt.Println("Sum:", op(3, 4))

    // Passing a function as an argument
    result := applyOperation(10, 5, op)
    fmt.Println("Result:", result)

    // Anonymous function
    diff := func(x, y int) int { return x - y }
    fmt.Println("Difference:", diff(10, 3))
}
