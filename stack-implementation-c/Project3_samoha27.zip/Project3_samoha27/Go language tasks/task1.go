package main

import "fmt"

// Global variable (accessible throughout the package)
var globalVar = "I'm global"

func main() {
    // Local variable (only accessible in this function)
    localVar := "I'm local"

    fmt.Println(globalVar)
    fmt.Println(localVar)

    {
        // Block-scoped variable (accessible only within this block)
        blockVar := "I'm inside a block"
        fmt.Println(blockVar)
    }

    // fmt.Println(blockVar) // Error: blockVar is not accessible here

    exampleFunction()
}

func exampleFunction() {
    // fmt.Println(localVar) // Error: localVar is not accessible here
    fmt.Println(globalVar) // This works because globalVar is package-scoped
}
