// extension4 task: Make a compilable and runnable haiku in the selected language. Less strict forms of poetry are also acceptable.

package main

import "fmt"

func main() {
    fmt.Println("Code flows like a stream,")
    fmt.Println("Logic dances in silence,")
    fmt.Println("Bugs fade with the dawn.")
}